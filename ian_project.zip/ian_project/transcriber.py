numList = ["number one", "number two", "number three", "number four",
           "number five", "number six", "number seven", "number eight", "number nine"]

class Transcriber:
    def __init__(self, text):
        self.text = text

    def transcribe(self):

        strr = self.text.lower()
        for i in range(len(numList)):
            if numList[i] in strr:
                strArr = strr.split(" " + numList[i] + " ", 1)
                res = strArr[0].capitalize()
                rest = strArr[1]
                restArr = rest.split(" number next ")
                idx = i + 1
                for j in range(len(restArr)):
                    res = res + "\n" + str(idx) + \
                        ". " + restArr[j].capitalize()
                    idx += 1
                break
        return res


class __main__:
    input = open("input.txt", "r").read()
    transcriber = Transcriber(input)
    transcribed_str = transcriber.transcribe()
    print(transcribed_str)
    output = open("output.txt", "w")
    output.write(transcribed_str)
    output.close()
