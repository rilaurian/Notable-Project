# Transcribe Doctor's Notes

## Prerequisites

- Python 3

## Instructions to run:

Download and extract source zip file.

In a terminal window, navigate to the extracted folder.

- text to be transcribed should go in the `input.txt` file at root of project

Run with below command:

```bash
python transcriber.py
```

This will output transcribed text to console and write to a new `output.txt` file at the root of project.
